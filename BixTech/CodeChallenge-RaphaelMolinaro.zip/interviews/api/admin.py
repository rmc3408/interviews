from django.contrib import admin
from .models import Empresa, Empregado

admin.site.register(Empresa)
admin.site.register(Empregado)