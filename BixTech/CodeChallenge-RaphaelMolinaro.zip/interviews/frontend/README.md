# To run FrontEnd
Technology used React 18

In the project directory, you can run:

### `npm install` to install all dependencies

### `npm run start` to open [http://localhost:3000](http://localhost:3000) 

### `npm run build` to the `build` folder.

### `npm run format` to the lint and organize your code.

### `npm run lint:fix` to the lint and fix warnings your code.